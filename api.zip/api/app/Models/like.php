<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class like extends Model
{
    use HasFactory;
    protected $table = 'like';
    protected $primaryKey = 'id';
    protected $fillable = [
        'post_id',
        'pengguna_id',            
    ];
}
