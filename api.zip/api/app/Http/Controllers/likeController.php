<?php

namespace App\Http\Controllers;
use App\Models\like;
use Illuminate\Http\Request;

class likeController extends Controller
{
    public function store(Request $request)
    {
        $like=like::where('pengguna_id',$request["pengguna_id"])
                    ->where('post_id',$request["post_id"])->first();
        if(!isset($like)){
            $like=like::create([
                'pengguna_id'       => $request["pengguna_id"],
                'post_id'           => $request["post_id"],                
            ]);
            return response()->json("like tersimpan"); 
        }
        else {
            return response()->json("1 pengguna hanya bisa 1 kali like pada post yang sama"); 
        }
    }
}
