<?php

namespace App\Http\Controllers;
use App\Models\post;
use Illuminate\Http\Request;

class UploadController extends Controller
{
    function upload(Request $request){
        //untuk single image 
        // $image=$request->file('image');
        // if ($request->hasFile('image')){
        //     $namabaru=rand().".".$image->getClientOriginalExtension();
        //     $image->move(public_path('/uploads/images'),$namabaru);
        //     return response()->json($namabaru);
        // }
        // else {
        //     return response()->json('Image kosong');
        // }
        //untuk multiple image
        $images=$request->file('image');
        $imagename="";
        if ($request->hasFile('image')){
            foreach($images as $image){
                $namabaru=rand().".".$image->getClientOriginalExtension();
                $image->move(public_path('/uploads/images'),$namabaru);
                $imagename=$imagename.$namabaru.",";
            }
            $imageall=$imagename;
            $post=post::create([
                'caption'       => $request["caption"],
                'images'        => $imageall,                
            ]);
            return response()->json($imageall."berhasil disimpan");
        }
        else {
            return response()->json('Image kosong');
        }
        
    }
}
