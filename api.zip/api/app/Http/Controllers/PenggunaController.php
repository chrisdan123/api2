<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\pengguna;
use App\Models\follow;
use App\Http\Controllers\Controller;
use App\Http\Requests\StorepenggunaRequest;
use App\Http\Requests\UpdatepenggunaRequest;

class PenggunaController extends Controller
{
    public $successStatus = 200;
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StorepenggunaRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StorepenggunaRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\pengguna  $pengguna
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request)
    {
        $input = $request->all();
        $pengguna=pengguna::where('id', $input['id'])->first();
        if (isset($pengguna)){
            $follower=follow::where('following', $input['id'])->count();
            $following=follow::where('follower', $input['id'])->count();
            return response()->json(['success' => $pengguna,'follower'=>$follower,'following'=>$following], $this->successStatus);
        }
        else {
            return response()->json(['error'=>'Data tidak ditemukan'], 401);
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\pengguna  $pengguna
     * @return \Illuminate\Http\Response
     */
    public function search(Request $request)
    {
        $input = $request->all();
        $pengguna=pengguna::where('firstname', 'like', "%{$input['nama']}%" )
                            ->orwhere('lastname', 'like', "%{$input['nama']}%" )->get();
        if (isset($pengguna)){
            
            return response()->json(['success' => $pengguna], $this->successStatus);
        }
        else {
            return response()->json(['error'=>'Data tidak ditemukan'], 401);
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdatepenggunaRequest  $request
     * @param  \App\Models\pengguna  $pengguna
     * @return \Illuminate\Http\Response
     */
    public function update(UpdatepenggunaRequest $request, pengguna $pengguna)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\pengguna  $pengguna
     * @return \Illuminate\Http\Response
     */
    public function destroy(pengguna $pengguna)
    {
        //
    }
}
