<?php

namespace App\Http\Controllers;
use App\Models\comment;
use Illuminate\Http\Request;

class commentController extends Controller
{
    public function store(Request $request)
    {
        if(isset($request["comment"])){
            $comment=comment::create([
                'pengguna_id'       => $request["pengguna_id"],
                'post_id'           => $request["post_id"],  
                'comment'           => $request["comment"],              
            ]);
            return response()->json("comment tersimpan"); 
        }
        else {
            return response()->json("Comment tidak boleh kosong"); 
        }
    }
}
